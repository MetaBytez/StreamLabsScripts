class ChatPGSettings(object):
    def __init__(self, settingsFile):
        self.settingsFile = settingsFile

    def Load(self, jsonData):
        pass

    def Save(self):
        pass
